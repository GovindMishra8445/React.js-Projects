import React, { useContext, useEffect, useState } from 'react'
import { ShopContext } from '../context/shopContext'
import Titele from './Title'
import ProductItem from './ProductItem';

const BestSeller = () => {
    const { products } = useContext(ShopContext);
    const [bestSeller, setBestSeller] = useState([])
    useEffect(() => {
        const bestProducts = products.filter((product) => (product.bestseller));
        setBestSeller(bestProducts.slice(0, 5));
    }, [])
    return (
        <div className='my-10'>
            <div className='text-center text-3xl PY-8'>
                <Titele text1={'BEST'} text2={'SELLERS'}/>
                <p className=' w-3/4 m-auto text-xs sm:text-sm md:text-base text-gray-600'>
                    Aliquam tincidunt mauris eu risus.
                    Lorem ipsum dolor, sit amet consectetur adipisicing elit. Eos error ipsum quam omnis nostrum dicta voluptatibus voluptate impedit! Deserunt odit tenetur nam voluptates eum nulla eaque, tempore quidem animi officiis?
        
                </p>
            </div>

            <div className='grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-y-6'>
                {bestSeller.map((product, index) => (
                    <ProductItem key={index}  id={product._id} name={product.name} image={product.image} price={product.price}/>
                    
                ))}
                </div>
        </div>
    )
}

export default BestSeller